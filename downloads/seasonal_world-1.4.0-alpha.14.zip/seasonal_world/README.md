# Seasonal World

Seasonal environments for Gen1Recomp in Pokémon Red, Blue, and Yellow. In summer, sunflowers sway by Oak’s Lab, sunlight glints along the southern sea, dragonflies visit the ponds of Fuchsia City and the Safari Zone, wind passes through the golden grass east of the city, and red-and-white fishing floats bob beside the piers on Route 12 and in Vermilion City. Pennants flutter on the road to Lavender Town. Farther north, blue and amber butterflies visit daisies on the way to Cerulean City and Bill’s house. Picnic blankets and paper pinwheels line the western trails from Mt. Moon to Viridian City. Paper kites fly above the ride through Celadon City and down Cycling Road. In western Kanto, fireflies rise from trailside ferns on summer evenings.

All 25 numbered routes in Kanto have places where petals drift from nearby flowers or flowering trees. The spring walk leads from Pallet Town through Viridian Forest, Pewter City, and Mt. Moon. From Cerulean City, head north to Bill's house, east to Rock Tunnel, or south to Vermilion City. Follow the coast to Lavender Town, head west through Saffron City to Celadon City, then ride Cycling Road to Fuchsia City. From Fuchsia, head east to Route 12 or follow the southern coast to Cinnabar Island and back to Pallet Town. To reach the Pokémon League, head west from Viridian City.

Christmas coverage includes all Kanto towns, Indigo Plateau, all 25 numbered routes, Viridian Forest, Vermilion Dock, and all four outdoor areas of the Safari Zone. Look for snowy paths and rooftops, frosted tall grass, Christmas lights, and trees with gifts. Face a Christmas tree and press **A** for a greeting.

## Install

1. Import `seasonal_world-1.4.0-alpha.14.zip` in Gen1Recomp. For a manual install, extract the `seasonal_world` folder into `mods`.
2. Enable **Seasonal World - Late Winter Preview**, then close Gen1Recomp completely and reopen it. Keep one copy of Seasonal World installed when updating.
3. Choose **SEASON → LATE WINTER TEST** for January snow or **THAW TEST** for the late-February walk from Pallet Town to Bill's house or the harbour in Vermilion City. **AUTO (DATE)** follows your local calendar. Keep **SNOW COVER** on to see the snow.

## New Year in Vermilion City

On the city pier in Vermilion City, watch gold, rose and blue fireworks over the water with reflections. In AUTO (DATE), the display runs from 23:30 on December 31 until 00:30 on January 1, using the device’s local clock. Three bursts mark midnight. Confetti stays until the end of January 1. From the sailor at the boarding end, walk three tiles north and one east, then face north and press A. NEW YEAR TEST plays the finale when the harbour comes into view, repeats it every 18 seconds and enables the confetti greeting. Christmas lights stay on.

## Late winter in Kanto

Late winter now covers all 42 outdoor maps. Follow the sheltered snow along Route 22 and the stone walls on Route 23 to Indigo Plateau. Stand just outside the Pokémon League doors. In January, the ground to either side is snowy; in late February, small patches cling to the foot of the wall. At Vermilion Dock, frost recedes to the fixed quay edge beside the gangway. Choose LATE WINTER TEST or THAW TEST with SNOW COVER enabled.

Late winter reaches the southern coast on Routes 19, 20 and 21 and around Cinnabar Island. January snow follows the waterline at the Route 19 beach, the Seafoam Islands and Cinnabar. Gaps open on February 1, and by February 20 only short strips remain. Stand one tile north of the Route 19 beach sign and compare LATE WINTER TEST with THAW TEST. The snow follows the beach in both Red/Blue and Yellow.

Follow the late-winter trail east from Fuchsia City along Routes 15, 14 and 13. January snow lines the ground below fences and ledges. In early February the paths clear while some frost remains in tall grass. From February 20 only short sheltered strips remain. Stand one tile south of the Route 13 sign in the fence maze and compare the ground below the fence on either side of the sign in LATE WINTER TEST and THAW TEST.

Late winter reaches Fuchsia City and all four outdoor Safari Zone areas. In Fuchsia, snow lingers at the corners of the Warden's house. Inside the Safari Zone, January snow traces the roof ridges of the four rest houses and the Secret House. On February 1 the middle clears, and from February 20 only snow on the two end caps remains. Stand outside the rest house in the Center Area to compare LATE WINTER TEST and THAW TEST with SNOW COVER enabled.

Late winter follows Cycling Road along Routes 16, 17 and 18. In January, snow traces the banks beside the road. From February 1 the white lines develop gaps, and from February 20 only short strips remain. Stop beside the Cycling Road Ends sign near the south end of Route 17. With SNOW COVER enabled, compare the two banks in LATE WINTER TEST and THAW TEST.

Snow along the fronts of the Underground Path buildings on Routes 7 and 8 retreats to the corners in February. In Celadon City, find the pond west of the Game Corner. Its northern bank carries a continuous white rim in January. The centre clears on February 1 and only the two tips remain from February 20. Compare LATE WINTER TEST and THAW TEST from the road directly below the middle of the pond.

The late-winter walk from Vermilion to Cerulean now passes through Route 6, Saffron City and Route 5. Long strips of January snow break up along the building fronts in early February. By February 20, small patches remain at the corners, with the doorways clear. In THAW TEST, stand outside the Day Care on Route 5 and look two tiles to the left and one to the right. Compare with LATE WINTER TEST at the same spot.

Along Route 12 and the Vermilion City pier, frost clings to the planks beside open water. The streaks shorten on February 1 and again on February 20. On Route 12, stand one tile south of the Sport Fishing sign and look at the eastern edge of the pier. On Route 11, snow lingers below the cliffs on either side of Diglett's Cave.

Snow settles against the cliffs on Routes 9 and 10. At the southern Rock Tunnel exit, look one tile to either side of the path below the cave mouth. In Lavender Town, two strips of snow beneath Pokémon Tower shrink on February 1 and again on February 20. Stand just outside the tower entrance to compare LATE WINTER TEST with THAW TEST.

Late winter reaches Cerulean City and Routes 24 and 25. Frost retreats along the outer planks of Nugget Bridge in February. A small strip of snow lingers below the garden fence west of Bill's house. In THAW TEST, stand outside Bill's door and look five tiles west.

Late winter begins on January 7 in Pallet Town and on Route 1. Snow lingers on Oak's Lab and frost settles on the grass. More grass shows on February 1 and again on February 20, through the last day of the month. In autumn, face the chestnut cart two tiles east of the tile outside the Route 7 Underground Path entrance and press A.

Late winter now reaches Viridian City, Route 2 and Viridian Forest. The city paths thaw first, leaving frost beside fences. Grass shows through at the edges of Route 2 from February 1. From February 20 a single patch of snow remains under a tree in Viridian Forest. From the southern Trainer Tips sign, look two tiles north and one tile west. Choose THAW TEST to see it on any date.

Late winter reaches Pewter City and Routes 3 and 4. The small icicles on Pewter Museum’s front eave shorten on February 1 and again on February 20. Snow melts first on open paths; drifts linger against the foothill rock faces. Stand just outside the western Mt. Moon entrance on Route 4 and look one tile west along the foot of the cliff. Compare LATE WINTER TEST with THAW TEST, with SNOW COVER enabled.

## Autumn in Kanto

Seven leaf piles line the walk from Pallet Town through Route 1 to Viridian City. On Route 1, look two tiles west of the route sign. In Viridian City, walk two tiles south from the tile outside the Pokémon Center. A gust lifts a red, gold or copper leaf, turns it in the air and drops it back onto the pile.

Seven mushroom clusters grow on Route 2, in Viridian Forest and in Pewter City. An acorn drops, bounces on the moss and rolls behind the caps. Look for red caps two tiles north of the Trainer Tips sign near the southern forest gate. In Pewter City, walk two tiles south from the tile just outside the Pokémon Center to see the golden cluster. AUTUMN MOTION holds the scene still when switched off.

Eight carved pumpkin lanterns line Route 3, Route 4 and Cerulean City. Look for a smiling face, a crescent moon and a star. The candlelight flickers gently inside the carvings. From the tile just outside the Cerulean Pokémon Center, walk three tiles east to the smiling pumpkin. AUTUMN MOTION off keeps the light steady.

Six Pidgey forage beside berry bushes on Routes 24 and 25. Each bird hops toward a low branch, pecks a berry and hops back. From the tile just outside Bill’s house, walk five tiles east to see one up close. AUTUMN MOTION off keeps the birds resting beside the bushes.

Eight autumn flower beds on Routes 9 and 10 and in Lavender Town shelter Gastly. From a distance, you see a faint violet mist. Approach the flowers to reveal Gastly hovering above them, then step away to watch it fade. From the tile just outside Pokémon Tower, walk two tiles east to the purple flowers. Turning off AUTUMN MOTION keeps Gastly still at each distance.

Red and golden maple leaves circle on the water at four fishing platforms on Route 12 and at two spots in Vermilion City. Look east from the Sport Fishing sign on Route 12 or across the inlet by the Old Rod house. Turn off AUTUMN MOTION to hold the leaves still.

Eight woven baskets stand beneath low apple branches on Routes 13, 14 and 15. Watch a red, golden or green apple fall, bounce once and settle in the basket. On Route 15 the first basket is one tile east and one tile south of the lower east door of the gate to Fuchsia City. AUTUMN MOTION off keeps the apple on its branch.

Paras peeks out of ten leaf piles in Fuchsia City and the four outdoor Safari Zone areas. Walk closer to reveal its spotted mushrooms and orange claws. Step back and it burrows into the leaves. The first pile is three tiles directly south of the Safari Zone gate door in Fuchsia City. AUTUMN MOTION off keeps its claw still at each distance.

Bicycle wheels stir ten drifts of red, gold and copper leaves on Routes 16, 17 and 18 and in Celadon City. Ride within three tiles to send the leaves spiralling up and back down. On Route 18 look one tile north of the route sign on the Fuchsia side of the gate. The drifts stay still on foot and with AUTUMN MOTION off.

Ten chestnut carts line the four approaches to Saffron City (Routes 5, 6, 7 and 8) and the city itself. Two wisps rise from each roasting pan beside a folded paper cone. On Route 7, walk two tiles east from the tile just outside the Underground Path entrance. Turn off AUTUMN MOTION to hold the steam still.

Ten tiny seashell boats bob on Routes 19, 20 and 21 and off Cinnabar Island. Each carries a twig mast and a red, gold or russet leaf sail. Look south from the Route 19 beach sign to see the red sail from shore: three tiles south in Red/Blue, one in Yellow. AUTUMN MOTION off holds the boats still.

Ten harvest wreaths decorate Route 11, Vermilion Dock, Routes 22 and 23, and Indigo Plateau. Each has autumn leaves and berries woven around a wooden hoop. At the dock, look for the sea-green ribbons. At Indigo Plateau, the violet ribbons flutter two tiles west of the tile just outside the left League door. AUTUMN MOTION off holds the ribbons still. All 42 outdoor maps now have autumn scenery.

## Summer in Kanto

Summer scenery now appears in all 42 outdoor areas covered by spring and Christmas.

Step outside Oak’s Lab in Pallet Town. A sunflower grows on either side of the approach. Other sunflowers grow near the player’s house and on the way to the water. Their heads lean one pixel as the breeze passes. At the southwest shore, pause to see the reflections brighten and fade. They continue on Route 21, around Cinnabar Island and on Routes 20 and 19.

On Route 19, walk south from Fuchsia City to the sign on the beach. The turquoise towel and orange sandals lie two tiles west of the sign, beside the water. In Yellow they are on the longer beach near the Summer Beach House.

In Fuchsia City, go to the pond behind the house where you receive the Good Rod. Stand on the south bank. A turquoise dragonfly perches on a cattail, skims the water, then returns. In the Safari Zone Center Area, follow the path past the right side of the rest house to the southeast bank of the pond. The East, North and West Areas each have a dragonfly and cattails by the water too.

Leave Fuchsia City through the eastern gate onto Route 15. Stand on the path beside the first patch of tall grass. Watch for six seconds as the golden seed heads bend from left to right and settle upright. On Route 14, look across the fence at the grass southwest of the route sign. On Route 13, look west from the waterside path below the Route 12 crossing. Sunlight also glints on open water along Routes 14 and 13.

Head north from Route 13 onto the Route 12 boardwalk and look to your right. A red-and-white fishing float tips in the swell. It gives a quick tug, slips below the surface, then rises through two widening rings. Watch for seven seconds to see the whole cycle. Look south from the Super Rod house door for a second float. Two more sit east of the Sport Fishing sign and beside the northern fishing platforms.

In Vermilion City, look left as you leave the house where you get the Old Rod. There is also a float just east of the sailor at the S.S. Anne boarding pier. Sunlight glints on open water in both maps. The scenery floats reappear after your own cast.

From Vermilion City, head north onto Route 6. Pennants hang across the front of the Saffron gate and above the entrance to the Underground Path. In Saffron City, look above the Pokémon Center or the Poké Mart. Follow Route 8 east to see the pennants at the gate and its Underground Path entrance.

In Lavender Town, stand just outside the Pokémon Center door, facing up. Watch the lilac pennants for six seconds. A gust reaches the four flags from left to right while the cord stays fixed to the roof. Another string hangs above Mr. Fuji’s door.

Walk north out of Lavender Town onto Route 10. A blue butterfly visits the two daisies at the entrance. Watch either flower head dip under its feet, then spring back when it leaves. Amber wings mark a second patch east of the sign at the south end of Rock Tunnel. At the north end, look south from the Pokémon Center. On Route 9, check near the western entrance, just east of the route sign, and along the eastern approach.

In Cerulean City, step outside the Pokémon Center and look left. A blue butterfly rests, spreads its wings, and flies to the next daisy. An eight-second cycle includes a higher flight out and a lower flight back. Another butterfly visits the grass on the approach to Nugget Bridge. On Route 24, look at the east bank from the bridge and the grass near its north end. Follow Route 25 from the western bend to Bill’s house. A blue butterfly visits the flowers just left of his cottage.

In Pewter City, start on the tile just outside the Pokémon Center door. Walk one tile south, keep facing down and press **A**. The paper pinwheel on the blue picnic blanket makes three extra turns and slows down. The breeze also turns the wheel if you simply wait. Each blanket has a wicker basket and a snack. Look for lemonade on blue cloth, a watermelon slice on red, and berries on green.

Another picnic lies on the lawn east of Pewter Museum. Route 3 has one near the Pewter entrance and another west of the route sign. On Route 4, look southeast from the Mt. Moon Pokémon Center or by the eastern entrance from Cerulean City. Route 2 has blankets on the approaches to both forest gates. In Viridian Forest, look near the boy in the southern clearing and south of the Trainer Tips sign on the eastern path. In Viridian City, visit the lawn south of the Pokémon Center and the lane leading north toward Route 2.

Twelve paper kites fly in Celadon City and on Routes 7, 16, 17 and 18. From the tile just outside the Celadon Pokémon Center, ride four tiles south and look just to your left for a red diamond kite. Ride within three tiles of the wooden reel and the kite climbs as its line pulls taut. It settles back into the breeze after a moment. Look for blue swallow kites and orange carp kites on the way down Cycling Road.

Walk north from Pallet Town to the Route 1 sign. Stand one tile to the left of the sign, beside the fern. Three fireflies drift higher as you approach, each with its own rhythm. Ten fern patches lie along Routes 1, 22 and 23 and outside the League at Indigo Plateau. Look just west of the League doors for the last group.

In **AUTO (DATE)** the fireflies rest on the leaves during the day. Their glow builds from 18:00 to 20:00 and fades from 04:00 to 06:00 on your device’s local clock. **SUMMER TEST** shows them at full evening light at any hour. With **SUMMER MOTION** off, the fireflies stay on the leaves with a steady evening glow.

**SUMMER MOTION** is on by default. Switch it off to hold the kites and pinwheels still, the butterflies resting on the left flower and the pennants hanging still. This also keeps the floats and seed heads upright, the dragonflies perched, and the sunflowers and water still.

Five lemonade tables with striped parasols appear on Route 5, on Route 11 and at Vermilion Dock. Step outside Day Care and look two tiles east of the door. On Route 11, look just southwest of the Diglett’s Cave entrance. The blue parasol at the dock stands east of the gangway on the fixed pier. SUMMER MOTION lets the parasols sway in the breeze.

## Spring walk

Start at the flower beds in Pallet Town. Look for pink primroses and yellow buttercups between the original flowers. Stand just below the flower bed by the town sign or by the one south of Oak’s Lab. A breeze lifts a petal from a primrose and sets it down beside the flower. Head north on Route 1. Near the boy in the southern part of the route, petals fall from the flowering trees by the path. Wildflowers grow along the edges of tall grass. In Viridian City, stand by the tree row just east of the Gym to see a few petals flutter down. Walk back across either boundary to see the same plants from the other side.

Continue north onto Route 2. Follow the wildflowers to the south gate and step through into Viridian Forest. Stand just to the right of the boy near the entrance and watch the pink blossoms on the tree above him. Every few seconds a petal loosens from the branch and flutters down. Wildflowers also grow at the edges of the tall grass. Both gate interiors keep their usual appearance.

Leave through the north gate and pause outside on Route 2 for petals from the trees by the entrance. In Pewter City, stand two tiles south of the Gym door and watch the tree row below you. Spring flowers also grow in the garden beds by the museum and east of the Pokémon Center. Take the eastern exit to Route 3. The first wildflowers grow on the grassy verges as you leave the city. Walk up to a yellow buttercup or pink primrose to see a petal lift from its head. Farther along, look around the tall grass between the ledges.

Follow Route 3 north to the Pokémon Center on Route 4. Look for a pink petal near the western entrance to Mt. Moon and yellow buttercups near the Route 4 sign east of the cave. Continue east past the tall grass into Cerulean City. Stand two tiles south of the Pokémon Center door to see pink and yellow petals above the flower bed. Blossoming trees also drop petals by the Bike Shop, and wildflowers grow on the bank east of Nugget Bridge.

Cross Nugget Bridge on Route 24. Look to the right for wildflowers along the riverbank, then turn east onto Route 25. Beyond the trainers, the flower beds lead to Bill's house. From the tile in front of his door, walk four tiles left to see both petal colors. A few more buttercups and primroses grow beside the pond east of the cottage.

For the mountain route, head east from Cerulean City and cut the tree at the start of Route 9. Pink and yellow petals rise from the flowers near the Route 9 sign between the ledges. On Route 10, pause in front of the north entrance to Rock Tunnel for pink petals. Flowers also grow near the Pokémon Center. With Surf, you can follow the river south to the yellow buttercups in front of the Power Plant. At the south exit of Rock Tunnel, stand two tiles below the cave mouth for more pink petals on the way to Lavender Town.

Back in Cerulean City, take the southern exit onto Route 5. Follow the ledges down to the Day Care. From the tile in front of its door, step left to see a buttercup release a yellow petal. Take the Underground Path to Route 6 and pause just outside the exit for pink petals. In Vermilion City, stand two tiles south of the Pokémon Center door for a yellow petal, or walk over to the Pokémon Fan Club sign for pink petals.

While the S.S. Anne is in port, take your S.S. Ticket to Vermilion Dock. Look to either side of the gangway for two low wooden flower boxes. The western box holds pink primroses and the eastern box holds yellow buttercups. Pause in the middle of the gangway. The two boxes take turns releasing a petal, each from one of its two flower heads. The boxes stay on the quay as the ship sails.

Head east from Vermilion City onto Route 11. From the tile in front of Diglett's Cave, step left and wait to see pink and yellow petals. More flowers grow in the grass near the eastern gate. On Route 12, the Super Rod house lies south of the junction. From the tile in front of its door, step left to see a golden petal lift from a buttercup.

Head north on Route 12 for Lavender Town. Stand one tile south of the Pokémon Tower door. The two nearby primroses release lilac petals that rise and settle a little more slowly than the pink and yellow ones on the routes. Look for the same shade outside Mr. Fuji's house.

Leave Lavender Town to the west. On Route 8, stand two tiles south of the Underground Path door for pink and yellow petals. In Saffron City, stand in front of the Fighting Dojo to see golden petals lift from the buttercups. More grow beside the west wall of Silph Co. On Route 7, pink and yellow petals drift just outside the Underground Path entrance. The Underground Path also connects the two routes if Saffron's gates are closed.

In Celadon City, walk to the trees just east of the Pokémon Center and watch the flowering branches take turns dropping petals. Pink primrose petals now drift along the lawn south of the Gym. For the pond, stand directly outside the Game Corner door and look left. A breeze carries a petal from the nearby primrose over the bank. A small ripple appears when it lands, then the petal floats a little way across the water before fading.

Head west onto Route 16. From the tile in front of the house where you get Fly, step left twice to see a pink petal. Pass through the cycling gate and ride down the eastern side of Route 17 beside the long flower bed. A breeze lifts pink and yellow petals in sequence down each column and carries them about one tile south. To watch from one spot, release the direction button and hold B to brake. On Route 18, look for pink petals just outside the eastern gate exit and more wildflowers by the Bird Keepers' grass patch.

In Fuchsia City, stand in front of the Safari Zone entrance and step one tile right or left. The pink primroses beside the doorway release petals. You can also see them from the tile in front of the Good Rod house next to the Warden's home.

Go through the Safari Zone gate. Pink primroses shed petals near the entrance and outside the rest houses. In the Center Area, walk past the right side of the rest house to the southeast corner of the pond. Stand beside a yellow buttercup and watch a golden petal land on the water. A small ripple spreads as the petal floats away. Look for the same buttercups at the water’s edge in the East, North and West Areas. In the West Area, pink petals also drift by the Secret House door.

Leave Fuchsia by the eastern gate on Route 15. Pause beside the Route 15 sign among the flower beds for pink petals. On Route 14, walk north past the sign and follow the flowers beside the tall grass. On Route 13, a yellow petal rises by the route sign between the fences. The wooden walkway continues north onto Route 12.

South of Fuchsia City, look for flowers as you descend the ledges to the Route 19 beach. In Yellow, stand just outside the Summer Beach House for a yellow petal. Surf west onto Route 20. At the Seafoam Islands, yellow buttercups grow next to the signs by the cave entrances, and pink primroses grow on the surrounding ground.

On Cinnabar Island, stand directly in front of the Pokémon Mansion or Pokémon Lab to see a pink primrose release a petal. More grow along the southern shore. Surf north on Route 21. The next blooms grow in the flower beds and at the edge of the tall grass just south of Pallet Town.

From Viridian City, head west onto Route 22. Look for wildflowers beside the tall grass and near the Pokémon League sign. Go through the gate and follow Route 23 north past the badge checks. Flowers grow along the banks on either side of the Surf section and outside both openings to Victory Road. At Indigo Plateau, the flowers stand in pairs just outside the rows of statues. The two lower pairs are pink and the top pair is gold. As you follow the middle aisle north, each left flower releases a petal toward the path, followed by its partner on the right. To see the golden pair, stand directly in front of either League door and wait through one breeze.

## Settings

| Setting | What it does |
|---|---|
| **SEASON → AUTO (DATE)** | Shows spring from March 1 through May 31, summer from June 1 through August 31, autumn from September 1 through November 30, Christmas from December 1 through January 6, and late winter from January 7 through the end of February, using your device's local date. This is the default. |
| **SEASON → LATE WINTER TEST** | Shows January snow from Pallet Town to Bill's house or the harbour in Vermilion City on any date. |
| **SEASON → NEW YEAR TEST** | Previews the midnight finale and January 1 confetti at the Vermilion City pier. |
| **SEASON → THAW TEST** | Shows the reduced snow cover from February 20 onward. |
| **SEASON → CHRISTMAS TEST** | Enables Christmas on any date. |
| **SEASON → SPRING TEST** | Shows spring flowers along the routes described above on any date. |
| **SEASON → SUMMER TEST** | Shows the summer scenery on any date. |
| **SUMMER MOTION** | Toggles the parasol breeze, firefly flight and pulsing light, kite flight and lift as you cycle past, the pinwheel breeze and A-button spins, butterfly flight and flower movement, fluttering pennants, float movement and ripples, wind in the grass, dragonfly flight, water glints and the sunflower breeze. |
| **SEASON → AUTUMN TEST** | Shows autumn on any date. |
| **AUTUMN MOTION** | Toggles tumbling leaves, falling acorns, pumpkin candlelight, foraging Pidgey, Gastly’s hover, floating maple leaves, falling apples and Paras’s claw. Also enables bicycle-triggered leaf swirls, steam from the chestnut carts, rocking shell boats and wreath ribbons. |
| **SEASON → OFF** | Turns off seasonal visuals and Christmas tree interactions and collision. |
| **SNOWFALL** | Toggles falling snow. |
| **SNOW COVER** | Toggles snow on the ground, rooftops, and scenery. |
| **FALLING PETALS** | On by default. Shows nearby drifting petals across all 25 numbered routes, the Kanto towns and cities, Viridian Forest, Vermilion Dock and all four outdoor Safari Zone areas. Also controls ripples from petals landing on ponds. Turn it off for stationary flowers. |

The seasonal effects run in the standard flat 2D view. Active world-rendering pipelines and tilt hide the effects. TileShift is optional. Alternate tilesets can shift scenery alignment.

## Christmas mobile test

With **CHRISTMAS TEST** active, try crossing each map boundary in both directions.

| Location | What to check |
|---|---|
| Route 2 ↔ Pewter City | The Christmas tree is already visible from Route 2 when it comes into view and stays in place as you cross. |
| Route 23 ↔ Indigo Plateau | The tree stays in place across the boundary, with snow on the trees along both sides. |
| Routes 8 and 12 ↔ Lavender Town | Check the snowy cliff tops from Route 8 and look for Lavender's Christmas tree as you approach from Route 12. |
| Route 16 ↔ Route 17 | Snow continues onto Cycling Road. Check the rails and both eaves of the house where you get Fly. |
| Route 24 ↔ Route 25 | Snow continues from Nugget Bridge toward Bill's house. Check the roof trim and windows. |
| Fuchsia City | Check the snowy trim and visible windows on the Warden's house and the Good Rod house. |
| Safari Zone | Walk past the tree near the Center entrance and press **A** while facing it. Check the ponds, posts, exits, and rest-house roofs. |

Try **OFF** outside beside a Christmas tree. The tree, snow, and trunk collision should disappear. If you report a visual issue, include the map or crossing, your game version, the tileset mods you use, and a screenshot if possible.

See [CHANGELOG.md](CHANGELOG.md) for version history.

Created by Tooandorisu.
